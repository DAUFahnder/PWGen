
browser.tabs.onActivated.addListener(PWGen_Background_Init);         


// Domain und alle eventuell damit verbundenen Daten aktualisieren:
function PWGen_Background_Init(){browser.tabs.query({currentWindow: true, active: true}).then(PWGen_logTabs, onError);}
              
function PWGen_logTabs(tabs) {
    let tab = tabs[0]; // D�rfte nur ein aktiver Tab im aktuellen Fenster sein...
    var url = new URL(tab.url);
    var url_strg = url.toString();
    
    if (url_strg.search("moz-extension://") != -1) { 
      console.log ("Erweiterung, keine Nutzung moeglich!");
      return;    
    };
    if (url_strg.search("file://") != -1) { 
      console.log ("Lokale Datei, derzeit keine Nutzung moeglich!");
      return;    
    };
    if (url.protocol == "about:") {     
      console.log ("about:-Seite, keine Nutzung moeglich!");
      return;    
    };
    PWGen_Aktuell.Domain = url.hostname;

    var regexp = /^[0-9,.]*$/;
    if (PWGen_Aktuell.Domain.match(regexp)) {
      console.log ("Reine IP-Adresse, derzeit keine Nutzung moeglich"); 
      return;
    };
    
    console.log("Background.js: " + PWGen_Aktuell.Domain);
}

function onError(err){
    console.error(err); 
}

